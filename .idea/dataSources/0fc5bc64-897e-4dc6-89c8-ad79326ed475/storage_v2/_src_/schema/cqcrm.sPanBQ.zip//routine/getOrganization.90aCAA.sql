CREATE PROCEDURE getOrganization(IN bh VARCHAR(10))
  begin
      SELECT id,name label, code, 1 status from backend_hrmsubcompany where companyid=bh
      UNION
      SELECT id,name label, code, 2 status from backend_hrmsubcompany WHERE supsubcomid = bh
      UNION
      SELECT id,name label, code, 3 status from backend_hrmdepartment WHERE subcompanyid = bh
      UNION
      SELECT id,name label, code, 4 status from backend_hrmdepartment WHERE supdepid = bh;
      #SELECT id,name label, code, 4 status from backend_hrmdepartment WHERE code like CONCAT(code, "%");
  end;
